<!DOCTYPE html>
<html lang="en">
<head>
    <title>jQuery Demo Document</title>
    <script
        type="text/javascript"
        src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"
    ></script>

    <script type="text/javascript">
        
        //Ready - Long Form
        // $(document).ready(
        //     alert("Page is ready")
        // );

        //Short-form 
        // $(
        //     alert("Page is ready - Short Form")
        // );

        //Multpline functionality 
        // $(
        //     function()
        //     {
        //         alert("First statement");
        //         alert("Second statement");

        //         document.writeln("Hello from jQuery");
        //     }
        // );

        // $(
        //     function()
        //     {
        //         //By using tag name
        //         // $("button").click(function()
        //         // {
        //         //     alert("Button is clicked");
        //         // });

        //         //By using id
        //         $("#btn").click(
        //             function()
        //             {
        //                 alert("Button is clicked - with Id");
        //             }
        //         );
        //     }
        // );

        //Accessing the attribute
        // $(
        //     function()
        //     {
        //         var data=$("#h1").attr("title");
        //         $("#h2").click(
        //             function()
        //             {
        //                 //alert(data);
        //                 $("#h2").text(data);
        //             }
        //         );
        //     }
        // );

        // $(
        //     function()
        //     {
        //         var flag=false;
        //         $("img").click(
        //             function()
        //             {
        //                 if(flag)
        //                 {
        //                     $("img").attr("src","a.png");
        //                     flag=false;
        //                 }
        //                 else
        //                 {
        //                     $("img").attr("src","b.png");
        //                     flag=true;
        //                 }
                        
        //             }
        //         );
        //     }
        // );

        // $(
        //     function()
        //     {
        //         var flag=0;
        //         $("#btn").click(
        //             function()
        //             {
        //                 if(flag===0)
        //                 {
        //                     $("h1").attr("align","center");
        //                     $("h1").text("I am in center");
        //                     flag=1;
        //                 }
        //                 else if(flag===1)
        //                 {
        //                     $("h1").attr("align","right");
        //                     $("h1").text("I am on right");
        //                     flag=2;
        //                 }
        //                 else if(flag===2)
        //                 {
        //                     $("h1").attr("align","left");
        //                     $("h1").text("I am on left");
        //                     flag=0;
        //                 }
        //             }
        //         );
        //     }
        // );

        $(document).ready(
            function()
            {
							var f=true;
                $("#h1").click(
                    function()
                    {
											if(f)
											 { 
												
												 $("#h1").removeClass("bg2");
												 $("#h1").addClass("bg1");
													f=false;
											 }
											 else
											 {
												
												$("#h1").removeClass("bg1");
												$("#h1").addClass("bg2");
												f=true;
											 }
                    }
                );

               
            }
        );
    </script>
    <style>
        .bg1
        {
            background-color: red;
        }
        .bg2
        {
            background-color: green;
        }
    </style>
</head>
<body>
    <!-- <button>Click Me</button> -->
    <!-- <button id="btn">Click Me</button> -->

    <!-- <h1 id="h1" title="We are Pakistani">First Heading</h1>
    <h2 id="h2">Click to change value</h2> -->

    <!-- <img src="b.png" width="100px" height="100px" border="1px"> -->

    <!-- <h1 id="h1" align="left">I am on Left</h1>
    <button id="btn">Click to change</button> -->

    <h1 id="h1">Heading with red bg</h1>
    <h1 id="h2">Heading with green bg</h1>
</body>
</html>


<!-- 
    Step 1- Add jQuery into our web Document -> Complete
    Step 2- Use jQuery's functionality  
-->
